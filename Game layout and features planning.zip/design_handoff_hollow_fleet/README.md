# Handoff: Hollow Fleet — Roguelike Deck-Builder Space Combat Game

## Overview
Hollow Fleet is a single-player, FTL-meets-Slay-the-Spire roguelike: the player commands the corvette **ISV Hollow Verdict** across a branching sector map, fighting card-based ship battles, docking at stations to buy cards/upgrades, and ultimately facing the dreadnought **HMS Iron Verdict**. This package documents the complete game design — UI, rules, content data, and behavior — for implementation in a real codebase.

## About the Design Files
The files in this bundle are **design references created in HTML** — a fully working prototype showing intended look, feel, and behavior. They are **not production code to copy directly**. The task is to **recreate this design in the target codebase's existing environment** (React, Vue, Svelte, canvas engine, etc.) using its established patterns and libraries — or, if no environment exists yet, choose the most appropriate framework and implement the design there.

`Hollow Fleet v2.dc.html` runs standalone in a browser (with `support.js`, `cards/`, and `ships/` alongside it). Its embedded `<script>` class contains the complete, working game logic — treat it as the authoritative rules spec.

## Fidelity
**High-fidelity.** Final colors, typography, spacing, and interactions. Recreate the UI pixel-perfectly using your codebase's libraries and patterns. All game balance numbers (card stats, enemy stats, prices) are final and live in the logic class.

## Screens / Views

### 1. Top Bar (persistent, all screens)
- 58px tall, full width. Border-bottom 1px `#1b2a45`, background linear-gradient 180deg `#0d1424` → `#070b14`.
- Left: "HOLLOW FLEET" — Space Grotesk 700, 20px, letter-spacing .2em, white. Then 1×22px divider `#22345a`, then a screen tag (`// GALACTIC SECTOR CHART`, `// ENGAGEMENT IN PROGRESS`, or `// STATION REFIT`) — IBM Plex Mono 12px `#5f7396`, letter-spacing .14em.
- Right: HUD readout — IBM Plex Mono 14px **amber `#ffc266`**: `◈ {salvage} SALVAGE · HULL {hull}/{max}` plus `· TURN {n}` in battle.

### 2. Sector Map ("THE HOLLOW VERGE")
- Centered header: kicker "GALACTIC SECTOR CHART" (mono 12px `#5f7396`, ls .3em), title "THE HOLLOW VERGE" (700, 36px, ls .12em, white), subtitle 15px `#8fa3c4`.
- Node field inset 110px/50px/120px/50px. Nodes positioned by % coordinates (see `NODES` in logic). Edges are dashed SVG lines (stroke-width .22, dasharray 1.1 1.1): active-from-current-node edges `#4fd8ff` at .95 opacity, others `#243350` at .45.
- Node = 40×40px diamond (square rotated 45°), 1.5px border, glyph centered (18px). Type colors: start ▣ `#7d92b5`, skirmish ⌖ `#5fd8ff`, elite ◈ `#ff8aa0`, station ⌂ `#7cf0c0`, anomaly ? `#b48aff`, flagship ⛧ `#ff5470`.
  - Current node: white border, bg `#182338`, pulsing outer diamond ring (`#4fd8ff`, keyframes scale 1→1.5, opacity .9→.12, 1.7s loop), tag "YOU ARE HERE" in `#4fd8ff`.
  - Reachable: type-colored border, glow `0 0 18px #4fd8ff55`, tag "JUMP READY" `#a9bcda`, cursor pointer.
  - Unreachable: border `#243350`, dimmed text `#4d6288`. Cleared: 0.3 opacity.
  - Label under node: 13px 600 uppercase ls .12em; tag line: mono 10px ls .18em.
- Bottom-left legend chip and bottom-right ship status card (hull bar, crew, deck size, salvage), both `#070b14cc` bg, 1px `#1b2a45` border, radius 5px.

### 3. Battle Screen
Layout: absolute-positioned central combat column (760px wide, horizontally centered, vertically centered between top bar and hand bar) + four corner panels + 190px hand bar pinned to bottom.
- **Combat column** scales to fit: `scale = min(1, (viewportH − 274) / 700, (viewportW − 24) / 760)`, transform-origin center. Contains enemy group and player group, 44px gap, mirrored vertically:
  - Enemy (top): subsystem row → ship image → shield bar. Player (bottom): shield bar → ship image → subsystem row.
  - **Ship images**: 200px tall, centered, `object-fit: contain`, drop-shadow `0 10px 26px #000000cc`. Enemy `ships/enemy.png` (aspect 2.685, faces left); player `ships/player.png` (aspect 2.434, faces right). A full-hull elliptical **shield bubble** (border-radius 50%, inset −14px −30px) sits behind: enemy border `#ff7d95` with `#ff5470` glows, player `#6fe0ff` with `#4fd8ff` glows; bubble opacity = `min(shield/cap, 1) × 0.6`.
  - **Subsystem cards** (×3 per ship: WEAPONS / REACTOR / ENGINES): flex row, gap 16px, margin 0 30px. Card: 1px border radius 4px, bg `#0a101ce6`, padding 8px 11px. Header row: 12px 600 uppercase ls .14em label + mono value. 6px progress bar on black, radius 2px. Status line: mono 11px `#5f7396` (e.g. "nominal", "aim degraded", "guns failing"). State colors — ok: text `#7d92b5`, border `#1b2a45`, bar gradient `#1e6f94→#4fd8ff`; warn (≤55): `#ffc266`, `#6b5a33`, `#b3813a→#ffc266`; crit (≤25): `#ff8aa0`, `#ff5470`, `#c23a55→#ff8aa0`.
  - **Shield bars**: label "SHIELD" mono 13px ls .2em `#7d92b5`; 13px bar, 1px `#2c4066` border on black; fill gradient — player `90deg #1e8fc4→#7ce7ff`, enemy `90deg #c23a55→#ff8aa0`; mono value right.
  - **Weapon tracers**: 3px × 240px vertical beams, gradient transparent→`#7ce7ff`→transparent, fade animation .55s, random x within column.
  - **Damage floats**: 30px 700 text rising 48px & fading over 1s. Hull damage `#ff8aa0`, shield absorb `#6fd8ff` (suffix " SH"). Positioned above enemy (`50% − 220px`) or below player (`50% + 160px`).
  - **Ship shake**: alternating ±2–5px translateX keyframes, .35s, on any hit.
- **Combat Log** (top-left): width min(300px, space to column edge − 40); hidden when < 150px. Bg `#070b14cc`, blur(2px). Entries mono 12.5px lh 1.5; enemy actions `#ff8aa0`, player actions `#9fdcff`, neutral `#5a6d8f`/`#b3c4de`; turn markers get dashed top border `#1b2a45`. Shows last 9 entries (3 when viewport < 680px tall).
- **Enemy plate** (top-right): tag chip "HOSTILE" (mono 10px `#ff8aa0`, border `#7a3244`) + name (600 17px white), role line (mono 11px `#7d92b5`), HULL bar (12px; gradient `180deg #8df2c8→#2aa878`, or red diagonal stripes `#ff5470`/`#5c1f2c` when ≤30%), CREW count.
- **Intent card** (under enemy plate): 3px left border + icon + text in intent color — attack `#ff5470` 🜂 "INCOMING FIRE {n}", shield `#4fd8ff` ⛨, boarding `#ffc266` ☖, repair `#7cf0c0` ✚. Subtitle mono 11px `#7d92b5`.
- **Player plate** (bottom-left, 204px above bottom): mirror of enemy plate with "FRIENDLY" chip (`#5fd8ff`, border `#1e4d66`).
- **Hand bar** (bottom, 190px): grid `minmax(170px,230px) / minmax(0,1fr) / minmax(150px,200px)`, border-top `#1b2a45`, bg gradient `#0b101df0→#04070ff8`.
  - Left cell — Reactor: label 12px 600 uppercase `#5fd8ff`; power pips 17×26px (filled: gradient `#8deaff→#2fbfe8` + glow `0 0 12px #4fd8ff77`; empty `#070b14`, border `#3a5580`), mono `{power}/{regen}`; "DRAW n · DISCARD n" mono 12px `#7d92b5`.
  - Center — hand of cards, bottom-aligned, centered; cards overlap (negative horizontal margins down to −55px) instead of shrinking when tight.
  - Right cell — END TURN button.
- **Card** (176px × ≥224px): radius 8px, border `#22345a`, bg `#0c1220`, shadow `0 6px 18px #000a`. Header: cost in 26px amber circle (`#ffc266`, dark text `#241503`, mono 14px 600) + type (mono 10px uppercase ls .22em `#7488ab`). Art: 84px full-width image (from `cards/{key}.png`). Name: 600 16px centered. Rules text: 12.5px `#8fa3c4` lh 1.35. Hover: translateY(−16px), border `#4fd8ff`. Unplayable: 0.4 opacity, no pointer.
- **Played-card animation**: card clone flies to column center, holds ~.6s, drifts up & fades (.9s total).
- **Primary buttons** (END TURN, UNDOCK, etc.): Space Grotesk 600 uppercase ls .14em, dark text `#03131c` on gradient `180deg #63e2ff→#2fbfe8`, border `#8deaff`, radius 4px, hard shadow `0 4px 0 #14506b`. Disabled: 0.45 opacity.

### 4. Space Base (station)
Scrollable page, max-width 1260px. Header: kicker "DOCKING CLAMPS ENGAGED", station name 34px 700, amber salvage chip, UNDOCK button. Two-column grid (1.7fr / 1fr, gap 20px):
- **The Armory**: 4 purchasable cards (card component + BUY button, mono 13px, disabled when unaffordable).
- **Shipyard**: 3 one-time upgrades (row: name 600 15px + desc 13px `#8fa3c4` + price/INSTALLED button).
- **Refit Bay**: PATCH HULL +15 (10◈), HIRE CREW +1 (8◈) buttons.
- **Deck Manifest** (full width below): chips with cost + name + ✕ scrap control (12◈, min 6 cards).

### 5. Overlays (briefing, reward, anomaly event, run end)
Centered modal on `#000000d8` + blur(3px). Panel: max-width 600–700px, radius 10px, border `#2c4066`, bg gradient `180deg #101828→#070b14`, shadow `0 24px 70px #000c`. Briefing has an 8px diagonal-stripe header band (`#4fd8ff`/`#0d1424` 45° stripes). Reward overlay shows +salvage (amber) and 3 card choices (hover lift) plus a ghost "take nothing" button. Run-end shows kicker/title/body + New Sortie (restart).

## Interactions & Behavior

### Run flow
1. Start → sector map + briefing overlay.
2. Player may jump only to nodes connected from current node (see `EDGES`), never back to cleared ones.
3. Node types: fight/elite → battle; base → station screen; anomaly → event overlay (choose +18 salvage or +2 crew); boss → final battle.
4. After a won battle (non-boss): +salvage (elite 36–46, normal 20–30), reward overlay (pick 1 of 3 random cards or skip), then auto-repair: +15% max hull, +1 crew, all subsystems +40, shields reset, return to map.
5. Boss win → victory end screen. Player hull ≤ 0 or crew ≤ 0 → defeat end screen. Restart resets everything.

### Battle loop
1. **Turn start (player)**: shields regen `round(3 × engines/100)`; power = `max(1, round(powerBase × (0.4 + 0.6 × reactor/100)))`; draw until 5 cards in hand (reshuffle discard into deck when empty); clear lock/brace/evade.
2. Player plays any number of affordable cards (cost ≤ remaining power; boarding cards also need crew). Card resolves immediately (see card list) with beam/float/shake/log feedback.
3. **END TURN**: hand discards; 500ms later the enemy executes its telegraphed intent; 600ms later a new intent is chosen and the next player turn starts. Buttons/cards disabled while busy.
4. Enemy turn-start: shields regen `round(regen × engines/100)`.
5. **Intent selection** (weighted random): attack w5 (damage `atkLo..atkHi`, `sab` chance to also hit a random player subsystem −12..22); shield w2 if below 40% cap (+`shieldAmt`); board w`boardCh×10` if player has crew (steal `boardN` crew + −10 random subsystem); repair w`rep×10` if hull < 55% or any subsystem < 50 (+8..14 hull, +25 worst subsystem). Displayed attack number = `round(value × (0.5 + 0.5 × weapons/100))` — recompute on subsystem changes.
6. **Damage resolution**: unless piercing, shields absorb first, remainder to hull. Weapon damage scales with attacker's WEAPONS: `round(dmg × (0.5 + 0.5 × weapons/100))`.
7. **Win/loss**: hull ≤ 0 (destroyed) or crew ≤ 0 (boarded/captured), either side. Checked after every resolution; 700ms beat before the outcome overlay.

### Cards (full list — key, name, cost, type, effect)
- laser — Laser Volley, 1, weapon: 7 dmg
- flak — Flak Barrage, 1, weapon: 5 dmg, +5 if enemy shields down
- missile — Missile Salvo, 2, weapon: 9 dmg, pierces shields
- railgun — Railgun Slug, 3, weapon: 13 dmg + enemy REACTOR −30
- broadside — Full Broadside, 2, weapon: 5 dmg × 3 hits
- torpedo — Torpedo Spread, 3, weapon: 15 dmg, pierces
- divert — Divert to Shields, 1, shield: +9 shields
- angle — Angle Deflectors, 1, shield: +5 shields, draw 1
- capacitor — Shield Capacitor, 2, shield: +14 shields
- brace — Brace for Impact, 1, shield: +4 shields, halve next hit
- dcontrol — Damage Control, 2, repair: worst subsystem +35, +5 hull
- patch — Hull Patch, 1, repair: +9 hull
- overcharge — Overcharge, 0, power: +2 power, own REACTOR −8
- reroute — Reroute Power, 0, power: +1 power, draw 1
- boarding — Boarding Party, 2, boarding: enemy crew −3, yours −1, random enemy subsystem −15, needs 2 crew
- breach — Breaching Pods, 3, boarding: enemy crew −5, yours −2, needs 3 crew
- lock — Target Lock, 1, tactic: next weapon this turn +7
- evasive — Evasive Burn, 1, tactic: dodge enemy's next attack
- scavenge — Scavenge, 0, tactic: draw 2

Starting deck: laser×4, divert×3, patch, missile, overcharge. Shop prices in `PRICE` map (10–30◈); shop stock = 4 random from `SHOP`; rewards = 3 random from `REWARDS`.

### Player ship & upgrades
Hull 64, crew 8, reactor 3 power/turn, shield cap 22, subsystems 100 each. Upgrades: Reinforced Plating +14 max hull (40◈), Shield Emitters +8 cap (35◈), Reactor Coils +1 power (50◈) — each once per run.

### Enemies (stats scale ×1.3 for elite nodes; difficulty multiplier: standard 1, hard 1.2, brutal 1.45 — applied to hull and attack)
- RSV Carrion Jackal, CORSAIR RAIDER: hull 44, shield 12/regen 3, crew 5, atk 5–9, sab .15, board 2@.15, shield+8
- PCS Ledger's Edge, ENFORCEMENT FRIGATE: hull 60, shield 16/regen 4, crew 7, atk 8–12, sab .25, board 2@.2, shield+10, repair .15
- HMS Iron Verdict, DREADNOUGHT · FLAGSHIP: hull 82, shield 22/regen 4, crew 10, atk 11–15, sab .28, board 3@.2, shield+13, repair .18

### Map graph
11 nodes, 16 edges — copy `NODES` and `EDGES` verbatim from the logic class.

## State Management
Single game-state object: `screen` (map/battle/base), `overlay` (brief/reward/ev/end/null), `salvage`, `current` node id, `cleared` set, `player` {hullMax, hull, crew, crewMax, powerBase, shieldCap, shield, subs{weapons,reactor,engines}, ups}, `deckKeys[]`, and per-battle state {enemy, turn, busy, over, lock, brace, evade, draw[], hand[], disc[], logs[], floats[], beams[], played, intent}. Transient FX (floats, beams, played card, shake counters) auto-expire via timeouts. Config props: `difficulty` (standard/hard/brutal), `startingSalvage` (default 40), `scanlines` (CRT overlay, default off).

## Design Tokens
**Colors**
- Backgrounds: page `#04070f`; panels `#070b14`, `#0a101c`, `#0c1220`, `#0d1424`, `#101828`; pure black wells `#000000`
- Borders: `#1b2a45` (default), `#22345a` (cards), `#2c4066` (strong), `#3a5580` (controls)
- Text: primary `#eaf2ff`, body `#d6e2f5`, secondary `#8fa3c4`, muted `#7d92b5`, faint `#5f7396`, mono-dim `#7488ab`
- Cyan (friendly/action): `#4fd8ff` base, `#7ce7ff`/`#8deaff` light, `#2fbfe8` deep, `#1e8fc4`/`#1e6f94` dark, button text `#03131c`, button shadow `#14506b`
- Red (hostile/damage): `#ff5470` base, `#ff8aa0` light, `#c23a55` deep, chip border `#7a3244`, stripe dark `#5c1f2c`
- Amber (salvage/power/cost): `#ffc266` base, `#b3813a` deep, border `#6b5a33`, dark text `#241503`
- Green (hull/station): `#8df2c8` → `#2aa878`; Violet (anomaly): `#b48aff`
- Starfield: white + `#9fd8ff` + `#ffd9a0` 1–1.5px dots; nebulas `#10294daa`, `#23164daa`, `#0c303d88`

**Typography**: Space Grotesk (400–700) for UI/display; IBM Plex Mono (400–600) for data, tags, logs. Scale: 10/11/12/13/15/16/17/20/30/34/36px. Letter-spacing: .1–.3em on uppercase labels.

**Radii**: 2px (bars), 3px (chips/buttons), 4–5px (panels), 8px (cards), 10px (modals), 50% (cost circles, shield bubbles).

**Shadows**: cards `0 6px 18px #000a`, modals `0 24px 70px #000c`, buttons `0 4px 0 <dark>`, glows `0 0 12–30px <accent>55–77`.

**Motion**: bar fills `width .3s`; card hover `.12s`; shake `.35s`; beam fade `.55s`; float rise 1s; card play .9s; ring pulse 1.7s loop; engine glow 1.3s loop. Respect `prefers-reduced-motion`.

## Assets
- `ships/player.png` (1200×493, transparent) and `ships/enemy.png` (1200×447, transparent, pre-flipped to face left) — chroma-keyed from user-supplied renders.
- `cards/*.png` — 19 procedurally generated monochrome line-art card illustrations (one per card key). Replaceable with final art at 176×84 display size.
- Google Fonts: Space Grotesk, IBM Plex Mono.
- Glyphs (⌖ ◈ ⌂ ⛧ 🜂 ⛨ ☖ ✚ ▣) are plain unicode text, not icons.

## Files
- `Hollow Fleet v2.dc.html` — the complete design: markup/styles + full game logic in the embedded script (authoritative for all rules and numbers)
- `support.js` — prototype runtime (ignore; not part of the design)
- `ships/` — ship sprites; `cards/` — card art
